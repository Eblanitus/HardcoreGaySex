using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace HardcoreMeleeMode.Content.Projectiles
{
    public class DaumSwordShockwave : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            Main.projFrames[Type] = 1;
        }

        public override void SetDefaults()
        {
            Projectile.width = 100;
            Projectile.height = 100;
            Projectile.friendly = true;
            Projectile.DamageType = DamageClass.Melee;
            Projectile.penetrate = -1;
            Projectile.tileCollide = false;
            Projectile.ignoreWater = true;
            Projectile.timeLeft = 30;
            Projectile.alpha = 255;
        }

        public override void AI()
        {
            Projectile.alpha -= 25;
            if (Projectile.alpha < 0)
                Projectile.alpha = 0;

            Projectile.scale = 1f + (30 - Projectile.timeLeft) * 0.1f;

            // Особый эффект: расширяющаяся волна
            if (Projectile.timeLeft % 3 == 0)
            {
                Dust.NewDust(Projectile.Center, 0, 0, DustID.Fire, 0f, 0f, 100, Color.OrangeRed, 2f);
            }

            // Особый эффект: звук ударной волны
            if (Projectile.timeLeft == 25)
            {
                Main.PlaySound(SoundID.Item14.WithVolume(0.5f), Projectile.Center);
            }
        }

        public override void OnHitNPC(NPC target, NPC.HitInfo hit, int damageDone)
        {
            // Особый эффект: отбрасывание
            target.velocity += new Vector2(10f, -5f);

            // Особый эффект: поджог
            target.AddBuff(BuffID.OnFire, 300);

            hit.HitDirection = (Projectile.Center.X < target.Center.X) ? 1 : (-1);
        }

        public override bool PreDraw(ref Color lightColor)
        {
            Texture2D texture = TextureAssets.Projectile[Type].Value;
            Rectangle sourceRectangle = texture.Frame();
            Vector2 origin = sourceRectangle.Size() / 2f;
            Vector2 drawPos = Projectile.Center - Main.screenPosition;

            // Особая отрисовка: волна с эффектом размытия
            Color color = new Color(255, 100, 0, Projectile.alpha) * 0.8f;
            Main.EntitySpriteDraw(texture, drawPos, sourceRectangle, color, 0f, origin, Projectile.scale, SpriteEffects.None, 0);

            return false;
        }
    }
}