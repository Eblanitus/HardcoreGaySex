using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace HardcoreMeleeMode.Content
{
    public class ExampleRecipes : ModSystem
    {
        public override void AddRecipes()
        {
            // Рецепт Daum Sword
            ModRecipe recipe = new ModRecipe(Mod);
            recipe.AddIngredient(ItemID.Obsidian, 50);
            recipe.AddIngredient(ItemID.HellstoneBar, 30);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(ModContent.ItemType<DaumSword>());
            recipe.AddRecipe();
        }
    }
}