using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace HardcoreMeleeMode.Content
{
	// Единственный HardcoreMeleePlayer на весь мод.
	// Схлопнут из 5 дублей (Challenges, Achievements, Bosses, Particles, Sounds).
	// Вся per-player/per-hit логика переехала сюда из ModSystem-классов,
	// потому что у ModSystem нет хуков OnHitNPCWithProj/OnPlayerHitByNPC/OnPlayerUpdate.
	public class HardcoreMeleePlayer : ModPlayer
	{
		// Режим
		public bool hardcoreModeActive = false;
		public bool prevHardcoreModeActive = false;

		// Вызовы (было: HardcoreMeleeChallenges)
		public bool noShieldChallenge = false;
		public bool noPotionsChallenge = false;
		public bool meleeOnlyChallenge = false;
		public bool bloodRageChallenge = false;
		public bool mercilessStrikeChallenge = false;

		// Вызовы (было: HardcoreMeleeBosses)
		public bool bossHunterChallenge = false;

		// Достижения (было: HardcoreMeleeAchievements)
		public bool meleeMaster = false;
		public bool meleeMasterUnlocked = false;
		public int ruthlessWarriorKills = 0;
		public bool ruthlessWarriorUnlocked = false;
		public bool impenetrableArmor = false;
		public bool impenetrableArmorUnlocked = false;

		// Было: HardcoreMeleeChallenges.OnPlayerUpdate + HardcoreMeleePenalties.PostUpdateMiscEffects
		public override void PostUpdateMiscEffects() {
			if (hardcoreModeActive) {
				if (noShieldChallenge) {
					Player.statDefense -= 20;
					Player.endurance -= 0.2f;
				}
				if (noPotionsChallenge) {
					Player.potionDelay = 3600;
				}
				if (meleeOnlyChallenge) {
					if (Player.HeldItem.damage > 0 && Player.HeldItem.DamageType != DamageClass.Melee) {
						Player.AddBuff(BuffID.Confused, 300);
						Player.statLife -= 5;
					}
				}
			}
			// Было: HardcoreMeleePenalties (без gating по режиму — сохранено как было)
			if (Player.HeldItem.damage > 0 && Player.HeldItem.DamageType != DamageClass.Melee) {
				Player.statDefense -= 10;
				Player.moveSpeed -= 0.2f;
			}
		}

		// Было: HardcoreMeleeBosses.OnPlayerUpdate.
		// В мультиплеере считает только локальный игрок, иначе бафф боссов сложится N раз.
		public override void PostUpdate() {
			if (hardcoreModeActive && Main.myPlayer == Player.whoAmI) {
				if (Player.activeNPCs > 0 && Player.npcTypeNoAggro == 0) {
					foreach (NPC npc in Main.npc) {
						if (npc.boss && npc.active) {
							npc.damage = (int)(npc.damage * 1.3f);
							npc.defense += 20;
							npc.lifeMax = (int)(npc.lifeMax * 1.5f);
							npc.life = npc.lifeMax;
						}
					}
				}
			}

			// Было: край активации из HardcoreMeleeEffects/Particles/Sounds.OnPlayerUpdate.
			// prevHardcoreModeActive раньше нигде не обновлялся (аура спамилась каждый тик) — теперь обновляем.
			if (hardcoreModeActive && hardcoreModeActive != prevHardcoreModeActive) {
				for (int i = 0; i < 20; i++) {
					Dust dust = Dust.NewDustDirect(Player.position, Player.width, Player.height, DustID.Fire, 0f, 0f, 100, Color.OrangeRed, 2.5f);
					dust.noGravity = true;
					dust.velocity *= 3f;
				}
				for (int i = 0; i < 15; i++) {
					Dust dust = Dust.NewDustDirect(Player.position, Player.width, Player.height, DustID.Fire, 0f, 0f, 100, Color.Orange, 2f);
					dust.noGravity = true;
					dust.velocity *= 2f;
				}
				Main.PlaySound(SoundID.Roar.WithVolume(0.9f), Player.Center);
			}
			prevHardcoreModeActive = hardcoreModeActive;
		}

		// Было: OnHitNPCWithProj из Achievements + Challenges + Bosses + Effects + Particles + Sounds + Penalties
		public override void OnHitNPCWithProj(Projectile projectile, NPC target, NPC.HitInfo hit, int damageDone) {
			if (projectile.DamageType != DamageClass.Melee) {
				return;
			}

			// Achievements: мастер ближнего боя
			if (damageDone >= 1000) {
				meleeMaster = true;
				if (!meleeMasterUnlocked) {
					meleeMasterUnlocked = true;
					Main.NewText("Достижение получено: Мастер ближнего боя!", Color.Gold);
				}
			}

			// Achievements: безжалостный воин
			if (hit.Crit) {
				ruthlessWarriorKills++;
				if (ruthlessWarriorKills >= 100) {
					ruthlessWarriorUnlocked = true;
					Main.NewText("Достижение получено: Безжалостный воин!", Color.Crimson);
				}
			}

			// Challenges: кровавая ярость (хил)
			if (bloodRageChallenge && hit.Crit) {
				Player.statLife += damageDone / 10;
				Dust.NewDust(Player.position, Player.width, Player.height, DustID.Blood, 0f, 0f, 100, Color.Red, 2f);
			}

			// Challenges + Effects: безжалостный удар (дебаффы)
			if (mercilessStrikeChallenge && damageDone > target.lifeMax / 2) {
				target.AddBuff(BuffID.BrokenArmor, 600);
				target.AddBuff(BuffID.WitheredArmor, 300);
				target.AddBuff(BuffID.WitheredWeapon, 300);
			}

			// Effects: кровавая ярость (пыль)
			if (bloodRageChallenge && hit.Crit) {
				for (int i = 0; i < 10; i++) {
					Dust dust = Dust.NewDustDirect(target.position, target.width, target.height, DustID.Blood, 0f, 0f, 100, Color.Red, 2f);
					dust.noGravity = true;
					dust.velocity *= 2f;
				}
			}

			// Particles: крит / убийство босса / промах
			if (hit.Crit) {
				for (int i = 0; i < 5; i++) {
					Dust dust = Dust.NewDustDirect(target.position, target.width, target.height, DustID.Blood, 0f, 0f, 100, Color.Red, 2f);
					dust.noGravity = true;
					dust.velocity *= 2f;
				}
			}
			if (target.boss && target.life <= 0) {
				for (int i = 0; i < 20; i++) {
					Dust dust = Dust.NewDustDirect(target.position, target.width, target.height, DustID.Fire, 0f, 0f, 100, Color.OrangeRed, 3f);
					dust.noGravity = true;
					dust.velocity *= 3f;
				}
			}
			if (!target.CheckDead() && !target.Hitbox.Intersects(projectile.Hitbox)) {
				for (int i = 0; i < 3; i++) {
					Dust dust = Dust.NewDustDirect(projectile.Center, 0, 0, DustID.Torch, 0f, 0f, 100, Color.Gray, 1f);
					dust.noGravity = true;
					dust.velocity *= 2f;
				}
			}

			// Sounds: крит / убийство босса / промах
			if (hit.Crit) {
				Main.PlaySound(SoundID.Item14.WithVolume(0.8f), projectile.Center);
			}
			if (target.boss && target.life <= 0) {
				Main.PlaySound(SoundID.NPCDeath14.WithVolume(1.2f), target.Center);
			}
			if (!target.CheckDead() && !target.Hitbox.Intersects(projectile.Hitbox)) {
				Main.PlaySound(SoundID.Item27.WithVolume(0.5f), projectile.Center);
			}

			// Bosses + Effects: босс-охотник
			if (target.boss && bossHunterChallenge && damageDone > target.lifeMax / 4) {
				target.AddBuff(BuffID.WitheredWeapon, 600);
				target.AddBuff(BuffID.WitheredArmor, 300);
				Projectile.NewProjectile(Projectile.GetSource_FromThis(), target.Center, Vector2.Zero, ModContent.ProjectileType<BossHunterMark>(), 0, 0f, Player.whoAmI);
			}

			// Penalties: мили-попадание по живому
			if (!target.CheckDead()) {
				Player.AddBuff(BuffID.StarInBottle, 300);
				Player.AddBuff(BuffID.Slow, 60);
			}
		}

		// Было: OnPlayerHitByNPC из Achievements + Effects + Particles + Sounds
		public override void OnHitByNPC(NPC npc, NPC.HitInfo hit, int damageDone) {
			// Achievements: непробиваемая броня
			if (Player.statDefense >= 50 && hit.Damage >= Player.statLifeMax2 / 2) {
				impenetrableArmor = true;
				if (!impenetrableArmorUnlocked) {
					impenetrableArmorUnlocked = true;
					Main.NewText("Достижение получено: Непробиваемая броня!", Color.Silver);
				}
			}

			if (!hardcoreModeActive) {
				return;
			}

			// Effects: серебряная пыль за танкование
			if (Player.statDefense >= 50 && hit.Damage >= Player.statLifeMax2 / 2) {
				for (int i = 0; i < 15; i++) {
					Dust dust = Dust.NewDustDirect(Player.position, Player.width, Player.height, DustID.Torch, 0f, 0f, 100, Color.Silver, 2f);
					dust.noGravity = true;
					dust.velocity *= 2f;
				}
			}

			// Particles: кровь за большой урон + серебро за блок
			if (hit.Damage >= Player.statLifeMax2 / 4) {
				for (int i = 0; i < 10; i++) {
					Dust dust = Dust.NewDustDirect(Player.position, Player.width, Player.height, DustID.Blood, 0f, 0f, 100, Color.DarkRed, 2f);
					dust.noGravity = true;
					dust.velocity *= 2f;
				}
			}
			if (Player.noKnockback && hit.Damage > 0) {
				for (int i = 0; i < 5; i++) {
					Dust dust = Dust.NewDustDirect(Player.position, Player.width, Player.height, DustID.Torch, 0f, 0f, 100, Color.Silver, 1.5f);
					dust.noGravity = true;
					dust.velocity *= 1.5f;
				}
			}

			// Sounds: большой урон + блок
			if (hit.Damage >= Player.statLifeMax2 / 4) {
				Main.PlaySound(SoundID.NPCDeath2.WithVolume(0.7f), Player.Center);
			}
			if (Player.noKnockback && hit.Damage > 0) {
				Main.PlaySound(SoundID.Item15.WithVolume(0.6f), Player.Center);
			}
		}
	}
}
