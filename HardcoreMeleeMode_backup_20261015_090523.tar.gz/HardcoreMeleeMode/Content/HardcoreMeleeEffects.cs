using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.GameContent;
using Terraria.ID;
using Terraria.ModLoader;

namespace HardcoreMeleeMode.Content
{
	// Логика эффектов переехала в HardcoreMeleePlayer.
	// Здесь остался только маркер босса.
	public class BossHunterMark : ModProjectile
    {
        public override void SetStaticDefaults()
        {
            Main.projFrames[Type] = 1;
        }

        public override void SetDefaults()
        {
            Projectile.width = 20;
            Projectile.height = 20;
            Projectile.friendly = false;
            Projectile.hostile = false;
            Projectile.tileCollide = false;
            Projectile.ignoreWater = true;
            Projectile.timeLeft = 300;
            Projectile.alpha = 255;
        }

        public override void AI()
        {
            Projectile.alpha -= 15;
            if (Projectile.alpha < 0)
                Projectile.alpha = 0;

            Projectile.scale = 1f + (300 - Projectile.timeLeft) * 0.01f;

            // Особый эффект: маркер босса
            if (Projectile.timeLeft % 5 == 0)
            {
                Dust.NewDust(Projectile.Center, 0, 0, DustID.Fire, 0f, 0f, 100, Color.Red, 1.5f);
            }
        }

        public override bool PreDraw(ref Color lightColor)
        {
            Texture2D texture = TextureAssets.Projectile[Type].Value;
            Rectangle sourceRectangle = texture.Frame();
            Vector2 origin = sourceRectangle.Size() / 2f;
            Vector2 drawPos = Projectile.Center - Main.screenPosition;

            // Особая отрисовка: маркер босса
            Color color = new Color(255, 0, 0, Projectile.alpha) * 0.8f;
            Main.EntitySpriteDraw(texture, drawPos, sourceRectangle, color, 0f, origin, Projectile.scale, SpriteEffects.None, 0);

            return false;
        }
    }
}