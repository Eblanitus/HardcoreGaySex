using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace HardcoreMeleeMode.Content
{
    public class HardcoreMeleeDamage : GlobalNPC
    {
        public override void ModifyHitByItem(NPC npc, Player player, Item item, ref NPC.HitModifiers modifiers)
        {
            // Хардкорный режим: увеличение урона от ближнего боя
            if (item.damage > 0 && item.DamageType == DamageClass.Melee)
            {
                modifiers.SourceDamage *= 1.5f; // +50% урона
                modifiers.SourceDamage *= item.knockBack > 0 ? 1.2f : 1f; // +20% если есть отбрасывание
            }
        }

        public override void ModifyHitByProjectile(NPC npc, Projectile projectile, ref NPC.HitModifiers modifiers)
        {
            // Хардкорный режим: увеличение урона от ближнего боя
            if (projectile.DamageType == DamageClass.Melee)
            {
                modifiers.SourceDamage *= 1.5f; // +50% урона
            }
        }
    }
}