using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace HardcoreMeleeMode.Content.Items.Placeable
{
    public class ExampleBar : ModItem
    {
        public override void SetStaticDefaults()
        {
            Item.ResearchUnlockCount = 5;
        }

        public override void SetDefaults()
        {
            Item.width = 20;
            Item.height = 20;
            Item.maxStack = 999;
            Item.value = Item.sellPrice(0, 0, 75);
            Item.rare = ItemRarityID.Green;
        }
    }
}