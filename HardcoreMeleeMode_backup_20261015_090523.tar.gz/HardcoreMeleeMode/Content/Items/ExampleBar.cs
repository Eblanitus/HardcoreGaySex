using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace HardcoreMeleeMode.Content.Items
{
    public class ExampleBar : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Example Bar");
            Tooltip.SetDefault("Материал для крафта хардкорного оружия");
        }

        public override void SetDefaults()
        {
            Item.width = 20;
            Item.height = 20;
            Item.maxStack = 999;
            Item.value = Item.buyPrice(gold: 1);
            Item.rare = ItemRarityID.Pink;
        }

        public override void AddRecipes()
        {
            // Рецепт крафта ExampleBar
            ModRecipe recipe = new ModRecipe(Mod);
            recipe.AddIngredient(ItemID.HellstoneBar, 5);
            recipe.AddIngredient(ItemID.Obsidian, 10);
            recipe.AddTile(TileID.MythrilAnvil);
            recipe.SetResult(this, 5);
            recipe.AddRecipe();
        }
    }
}