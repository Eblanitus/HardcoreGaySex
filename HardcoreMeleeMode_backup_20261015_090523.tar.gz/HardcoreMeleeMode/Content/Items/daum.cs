using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace HardcoreMeleeMode.Content.Items
{
	// This is a basic item template.
	// Please see tModLoader's ExampleMod for every other example:
	// https://github.com/tModLoader/tModLoader/tree/stable/ExampleMod
	public class daum : ModItem
	{
		// The Display Name and Tooltip of this item can be edited in the 'Localization/en-US_Mods.HardcoreMeleeMode.hjson' file.
public override void SetDefaults()
{
    Item.damage = 500;
    Item.DamageType = DamageClass.Melee;
    Item.width = 400;
    Item.height = 400;
    Item.useTime = 60;
    Item.useAnimation = 60;
    Item.useStyle = ItemUseStyleID.Swing;
    Item.knockBack = 60;
    Item.value = Item.buyPrice(gold: 10);
    Item.rare = ItemRarityID.Purple;
    Item.UseSound = SoundID.Item1;
    Item.autoReuse = true;
}

		public override void AddRecipes()
		{
			Recipe recipe = CreateRecipe();
recipe.AddIngredient(ItemID.DirtBlock, 10);
recipe.AddTile(TileID.WorkBenches);
			recipe.Register();
		}
	}
}
