using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace HardcoreMeleeMode.Content.Items.Weapons
{
    public class DaumSword : ModItem
    {
        public override void SetStaticDefaults()
        {
            DisplayName.SetDefault("Daum Sword");
            Tooltip.SetDefault("Огромный меч с огромным уроном\nИспользуйте с осторожностью");
        }

        public override void SetDefaults()
        {
            Item.damage = 150;
            Item.DamageType = DamageClass.Melee;
            Item.width = 80;
            Item.height = 80;
            Item.useTime = 40;
            Item.useAnimation = 40;
            Item.useStyle = ItemUseStyleID.Swing;
            Item.knockBack = 10f;
            Item.value = Item.buyPrice(gold: 50);
            Item.rare = ItemRarityID.Red;
            Item.UseSound = SoundID.Item1;
            Item.autoReuse = true;
            Item.shoot = ModContent.ProjectileType<DaumSwordProjectile>();
            Item.noMelee = true;
            Item.shootsEveryUse = true;
        }

        public override void AddRecipes()
        {
            CreateRecipe()
                .AddIngredient(ItemID.Obsidian, 50)
                .AddIngredient(ItemID.HellstoneBar, 30)
                .AddTile(TileID.MythrilAnvil)
                .Register();
        }
    }
}