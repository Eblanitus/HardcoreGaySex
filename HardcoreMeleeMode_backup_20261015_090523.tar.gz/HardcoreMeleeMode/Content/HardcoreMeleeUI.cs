using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.GameContent;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.UI;

namespace HardcoreMeleeMode.Content
{
    public class HardcoreMeleeUI : ModSystem
    {
        public override void ModifyInterfaceLayers(List<GameInterfaceLayer> layers)
        {
            // Добавляем интерфейс хардкорного режима
            int resourceBarIndex = layers.FindIndex(layer => layer.Name.Equals("Vanilla: Resource Bars"));
            if (resourceBarIndex != -1)
            {
                layers.Insert(resourceBarIndex, new LegacyGameInterfaceLayer("HardcoreMeleeMode: Hardcore Interface",
                    delegate {
                        Player player = Main.LocalPlayer;
                        if (player.GetModPlayer<HardcoreMeleePlayer>().hardcoreModeActive)
                        {
                            DrawHardcoreInterface(player);
                        }
                        return true;
                    },
                    InterfaceScaleType.UI));
            }
        }

        private void DrawHardcoreInterface(Player player)
        {
            SpriteBatch spriteBatch = Main.spriteBatch;
            HardcoreMeleePlayer modPlayer = player.GetModPlayer<HardcoreMeleePlayer>();

            // Фон интерфейса
            spriteBatch.Draw(TextureAssets.MagicPixel.Value, new Rectangle(10, 10, 200, 120), null, new Color(0, 0, 0, 150));
            spriteBatch.Draw(TextureAssets.MagicPixel.Value, new Rectangle(8, 8, 200, 20), null, new Color(100, 0, 0, 200));
            Utils.DrawBorderStringFourWay(spriteBatch, FontAssets.MouseText.Value, "Хардкорный режим", new Vector2(110, 18), Color.Gold, Color.Black, new Vector2(0.5f));

            // Статистика
            Utils.DrawBorderStringFourWay(spriteBatch, FontAssets.MouseText.Value, "Урон: +50%", new Vector2(20, 45), Color.White, Color.Black, Vector2.Zero);
            Utils.DrawBorderStringFourWay(spriteBatch, FontAssets.MouseText.Value, "Защита: -10", new Vector2(20, 65), Color.White, Color.Black, Vector2.Zero);
            Utils.DrawBorderStringFourWay(spriteBatch, FontAssets.MouseText.Value, "Скорость: -20%", new Vector2(20, 85), Color.White, Color.Black, Vector2.Zero);

            // Активные вызовы
            int yOffset = 110;
            if (modPlayer.noShieldChallenge)
            {
                Utils.DrawBorderStringFourWay(spriteBatch, FontAssets.MouseText.Value, "Без щита", new Vector2(20, yOffset), Color.Red, Color.Black, Vector2.Zero);
                yOffset += 20;
            }
            if (modPlayer.noPotionsChallenge)
            {
                Utils.DrawBorderStringFourWay(spriteBatch, FontAssets.MouseText.Value, "Без зелий", new Vector2(20, yOffset), Color.Red, Color.Black, Vector2.Zero);
                yOffset += 20;
            }
            if (modPlayer.meleeOnlyChallenge)
            {
                Utils.DrawBorderStringFourWay(spriteBatch, FontAssets.MouseText.Value, "Только ближний бой", new Vector2(20, yOffset), Color.Red, Color.Black, Vector2.Zero);
                yOffset += 20;
            }

            // Достижения
            yOffset = 110;
            if (modPlayer.meleeMasterUnlocked)
            {
                Utils.DrawBorderStringFourWay(spriteBatch, FontAssets.MouseText.Value, "Мастер ближнего боя", new Vector2(120, yOffset), Color.Gold, Color.Black, Vector2.Zero);
                yOffset += 20;
            }
            if (modPlayer.ruthlessWarriorUnlocked)
            {
                Utils.DrawBorderStringFourWay(spriteBatch, FontAssets.MouseText.Value, "Безжалостный воин", new Vector2(120, yOffset), Color.Crimson, Color.Black, Vector2.Zero);
                yOffset += 20;
            }
        }
    }
}