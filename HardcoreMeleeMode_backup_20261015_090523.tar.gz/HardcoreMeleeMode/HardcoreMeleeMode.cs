using System;
using System.Collections.Generic;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using HardcoreMeleeMode.Content;
using HardcoreMeleeMode.Content.Items;
using HardcoreMeleeMode.Content.Projectiles;

namespace HardcoreMeleeMode
{
    public class HardcoreMeleeMode : Mod
    {
        public override void Load()
        {
            // Мод загружен
        }
    }
}
